package com.city.finder.service;

import com.city.finder.model.City;
import java.io.BufferedWriter;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.SneakyThrows;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.tomcat.util.buf.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class CityService {

  public static String CITY_CSV_FILE_PATH = "cities.csv";

  @SneakyThrows
  public City Save(City city) {
    try (
        BufferedWriter writer = Files.newBufferedWriter(
            Paths.get(ClassLoader.getSystemResource(CITY_CSV_FILE_PATH).toURI()));

        CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
            .withSkipHeaderRecord());
    ) {
      csvPrinter.printRecord(city.getId(), city.getName(), city.getPhoto());
      csvPrinter.flush();
    }
    return city;
  }

  @SneakyThrows
  public List<City> getCities(String name) {
    try (
        Reader reader = Files.newBufferedReader(
            Paths.get(ClassLoader.getSystemResource(CITY_CSV_FILE_PATH).toURI()));
        CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT
            .withFirstRecordAsHeader()
            .withIgnoreHeaderCase()
            .withTrim());
    ) {
      List<City> cities = new ArrayList<>();
      for (CSVRecord csvRecord : csvParser) {
        if( isNullOrEmpty(name) || (!isNullOrEmpty(name) && name.contains(csvRecord.get("name")))) {
          cities
              .add(
                  new City(Integer.parseInt(csvRecord.get("id")),
                      csvRecord.get("name"), csvRecord.get("photo")));
        }
      }
      return cities;
    }
  }

  @SneakyThrows
  public List<City> getCities() {
    return getCities(null);
  }

  private boolean isNullOrEmpty(String name) {
    return name == null || name.isEmpty();
  }
}
