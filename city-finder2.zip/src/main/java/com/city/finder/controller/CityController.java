package com.city.finder.controller;

import com.city.finder.model.City;
import com.city.finder.service.CityService;
import java.io.Reader;
import java.nio.file.Files;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/city")
public class CityController {

    @Autowired
    private CityService cityService;

    @GetMapping("/{name}")
    public List<City> getCity(@PathVariable("name") String name) {
        return cityService.getCityByName(name);
    }

    @GetMapping()
    public List<City> getAllCity() {
        return cityService.getAllCities();
    }

    @PostMapping()
    public City Save(City city){
        return cityService.Save(city);
    }

}
